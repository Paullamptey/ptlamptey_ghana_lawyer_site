// Simple conversational UI with Ghanaian-inspired motif
const chatToggle = document.getElementById('chat-toggle');
const chatPanel  = document.querySelector('.chat-panel');
const chatLog    = document.getElementById('chat-log');
const chatInput  = document.getElementById('chat-input');
const chatSend   = document.getElementById('chat-send');

function addMsg(role, text){
  const block = document.createElement('div');
  block.className = `msg ${role}`;
  block.innerHTML = `<div>${text}</div><div class="msg-meta">${new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} • ${role==='bot'?'Read':'Sent'}</div>`;
  chatLog.appendChild(block);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function typing(on=true){
  let t = document.querySelector('.typing');
  if(on && !t){
    const el = document.createElement('div');
    el.className='typing';
    const wrap = document.createElement('div');
    wrap.className='msg bot';
    wrap.appendChild(el);
    chatLog.appendChild(wrap);
    chatLog.scrollTop = chatLog.scrollHeight;
  }else if(!on && t){
    t.parentElement.remove();
  }
}

chatToggle.addEventListener('click', ()=>{
  chatPanel.classList.toggle('open');
  if(chatPanel.classList.contains('open') && chatLog.children.length===0){
    setTimeout(()=>{
      addMsg('bot', 'Akwaaba. I can help with case types, appointments, complaints, and FAQs about Ghanaian legal processes. How may I assist?');
    }, 150);
  }
});

chatSend.addEventListener('click', handleSend);
chatInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ handleSend(); } });

function handleSend(){
  const text = chatInput.value.trim();
  if(!text) return;
  addMsg('user', text);
  chatInput.value = '';
  typing(true);
  setTimeout(()=>{
    typing(false);
    route(text);
  }, 600);
}

// Basic intent routing for case type, appointments, complaints, FAQ
function route(text){
  const t = text.toLowerCase();

  // Case type detection
  if(/family|marriage|custody|maintenance|adoption/.test(t)){
    addMsg('bot', 'Family Law: we advise on customary and ordinance marriages, custody, maintenance, and adoption under the Children’s Act. Would you like to book a consultation? Type: appointment [date] [time].');
    return;
  }
  if(/property|land|title|conveyance|conveyancing/.test(t)){
    addMsg('bot', 'Property & Land: title searches, conveyancing and Land Act compliance with filings at the Lands Commission. To schedule, type: appointment [date] [time].');
    return;
  }
  if(/immigration|permit|residence|citizenship|gis/.test(t)){
    addMsg('bot', 'Immigration: residence permits, citizenship guidance and application tracking with GIS. To begin, type: appointment [date] [time].');
    return;
  }
  if(/company|corporate|roc|compliance|contract/.test(t)){
    addMsg('bot', 'Corporate & Compliance: formation, ROC filings, and contract review. To proceed, type: appointment [date] [time].');
    return;
  }
  if(/criminal|bail|charge|trial/.test(t)){
    addMsg('bot', 'Criminal Defence: representation from charge to trial and bail applications with constitutional safeguards. To meet counsel, type: appointment [date] [time].');
    return;
  }

  // Appointment intent
  const appMatch = t.match(/appointment\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})/);
  if(appMatch){
    const [_, date, time] = appMatch;
    addMsg('bot', `Booked request for ${date} at ${time}. You’ll get confirmation shortly.`);
    // Submit via AJAX to backend
    fetch('server/handlers/submit_appointment.php',{method:'POST',headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name:'Chat User', email:'chat@local', phone:'N/A', type:'General', date, time })
    }).catch(()=>{});
    return;
  }

  // Complaint intent
  if(/complaint|report|issue/.test(t)){
    addMsg('bot', 'Please provide your complaint in the format: complaint [category] [urgency: low|medium|high] [details].');
    return;
  }
  const compMatch = t.match(/complaint\s+(\w+)\s+(low|medium|high)\s+(.+)/);
  if(compMatch){
    const [_, category, urgency, details] = compMatch;
    addMsg('bot', 'Complaint received. We will acknowledge by email and follow up.');
    fetch('server/handlers/submit_complaint.php',{method:'POST',headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name:'Chat User', email:'chat@local', phone:'N/A', category, urgency, details })
    }).catch(()=>{});
    return;
  }

  // FAQ
  if(/land commission|lands commission/.test(t)){
    addMsg('bot', 'Lands Commission: we conduct official searches, validate parcel identity and interests, then prepare deeds for stamping and registration.');
    return;
  }
  if(/fees|cost|charge|pricing/.test(t)){
    addMsg('bot', 'Fees: we provide written fee quotes and scope letters in line with professional conduct rules. Initial consultations are billed per agreed terms.');
    return;
  }
  if(/how to book|book|schedule/.test(t)){
    addMsg('bot', 'You can book via the Appointment form, or type: appointment YYYY-MM-DD HH:MM.');
    return;
  }

  // Fallback
  addMsg('bot', 'I can help with case types, appointments, complaints, and FAQs. Try: “appointment 2025-09-20 10:00” or “family law”.');
}
