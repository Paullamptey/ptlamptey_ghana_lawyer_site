# Ghanaian Personal Lawyer Website

A complete, responsive website for a Ghana-based personal lawyer with a floating chatbot, secure AJAX forms, PHP backend, MySQL schema and email notifications.

## Quick start
1. Copy the folder to your PHP server root (e.g., XAMPP `htdocs`).
2. Create a MySQL database called `ghana_lawyer` and run `server/sql/schema.sql`.
3. Edit `server/config.php` with your DB credentials and email settings.
4. If you want SMTP, `composer require phpmailer/phpmailer` and ensure autoloading in your project, then set `smtp.enabled=true` in config.
5. Visit `index.html` in your browser via your local server URL.

## Endpoints
- `server/handlers/submit_contact.php`
- `server/handlers/submit_appointment.php`
- `server/handlers/submit_complaint.php`

All endpoints accept JSON POST and return `{ ok: boolean, message?: string, error?: string }`.

## Security
- Prepared statements to prevent SQL injection
- Basic IP rate limiting
- Server-side validation
- Recommend adding CSRF token and Google reCAPTCHA in production

## Ghanaian Legal Context
Text uses Ghana-appropriate terms: 1992 Constitution, Lands Commission, Land Act, GIS procedures, Registrar of Companies, professional conduct rules. Adapt to your exact practice.

## Branding & Animations
- Ghana colors used as accents with a dark professional base
- Kente-inspired stripes and Adinkra-like badges
- Smooth intersection reveals and microinteractions
